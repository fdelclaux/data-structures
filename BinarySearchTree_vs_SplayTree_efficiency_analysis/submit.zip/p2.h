/*
*   Author: Felipe Delclaux
*   Project #2a
*   p2.h
*   February 14, 2020
*   COSC160
*/

#include <iomanip>
#include <chrono>
#include <ctime>
#include <vector>

#include "BST.h"
#include "ST.h"

using namespace std;
